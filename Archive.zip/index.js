"use strict";

const AWS = require("@aws-sdk/client-s3");

AWS.config.update({ region: "us-west-2" });

let S3 = new AWS.S3();

exports.handler = async (event) => {
  let downloaded = await download();
  let list = downloaded.body;

  console.log("Body:", list, typeof list);

  let metadata = event.Records[0].s3.object;
  let metaJSON = JSON.stringify(metadata, null, 2);

  console.log("Metadata:", metaJSON);
  list.push(metaJSON);
  //   await uploadOnS3("images.json", list);
  console.log("Image List: ", list);
  await putObjectToS3(bucket, "images.json", list);
};

async function download() {
  try {
    const data = await S3.getObject({
      Bucket: bucket,
      Key: "images.json",
    }).promise();

    return {
      statusCode: 200,
      body: JSON.parse(data.Body.toString("utf-8")),
    };
  } catch (err) {
    return {
      statusCode: err.statusCode || 400,
      body: err.message || JSON.stringify(err.message),
    };
  }
}

async function putObjectToS3(bucket, key, data) {
  var s3 = new AWS.S3();
  var bucketParams = {
    Bucket: bucket,
    Key: key,
    Body: JSON.stringify(data),
  };

  await s3.putObject(bucketParams, function (err, data) {
    if (err) {
      console.log("error", err);
    } else {
      console.log("success", data);
    }
  });
}

/*s3.listObject(bucketParams, function (err, data) {
  if (err) {
    console.log("error", err);
  } else {
    console.log("success", data);
  }
});*/

//////index.js /////DynaMoose API
/*
npm dynamoose uuid

"use strict"

const uuid = require("uuid").v4;
const dynamoose = require("dynamoose");
const contactModel = require("./contacts.schema.js");

//get and generate data to shove into database
exports.handler = async (event) => {
  //1. save thing into db
  //2. respond with the thing or an "ok message"

  try{
    //1. get data from request body 
    const {name,phone} = JSON.parse(event.body) //object destructure

    // make a unique id for this record
    const id = uuid();
    //make record based on dynamoos schema
    const record = new ContactModel({id, name,phone});
    const data = await.record.save();
    //return newly saved data 
    return {
      statusCode: 200,
      body: JSON.Stringify(data);
    }
  } 
  catch(e) { 
    return {
      statusCode: 500,
      response: e.message
    }
  }
}
*/

////contacts.schema.js
// much like mongodb shema
/*

"use strict"

const dynamoose = require("dynamoose");
const contactShema = new dynamoose.Schema({
  'testID': String,
  'name': String,
  'phone': String
});
                            //name of the table in AWS side
module.exports = dynamoose.model("contacts",contactSchema);
*/
