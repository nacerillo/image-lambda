"use strict";

const AWS = require("@aws-sdk/client-s3");

AWS.config.update({ region: "us-west-2" });

let s3 = new AWS.S3({ apiVerson: "2006-03-01" });

var bucketParams = {
  Bucket: "funner-bucket",
};

s3.listObject(bucketParams, function (err, data) {
  if (err) {
    console.log("error", err);
  } else {
    console.log("success", data);
  }
});
